// //the relationship association
// const sequelize = require('../config/database');
// const User = require('./User');
// const Job = require('./Job');
// const JobApplication = require('./JobApplication');
// const RefreshToken = require('./RefreshToken');

// const models = { User, Job, JobApplication, RefreshToken };

// // Initialize associations
// Object.values(models).forEach(model => {
//   if (model.associate) {
//     model.associate(models);
//   }
// });

// module.exports = {
//   sequelize,
//   User,
//   Job,
//   JobApplication,
//   RefreshToken,
// };